export default function Shell({ children }: { children: React.ReactNode }) {
  return <main className="mx-auto min-h-screen max-w-lg px-4 pb-28 pt-5">{children}</main>;
}
