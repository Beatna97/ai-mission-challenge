export type Phase = 'lobby' | 'reveal' | 'discussion' | 'voting' | 'results';
export type Player = { id: string; name: string; ready: boolean; online: boolean; voted: boolean };
export type Result = { spyId: string; location: string; winner: 'players' | 'spy'; reason: 'vote' | 'escaped' | 'guess_ok' | 'guess_bad'; guess?: string };
export type RoomState = {
  code: string; phase: Phase; hostId: string; me: string; now: number; endsAt: number | null; minPlayers: number;
  players: Player[]; locations: string[]; role: 'spy' | 'player' | null; location: string | null; myVote: string | null;
  votes: Record<string, string> | null; result: Result | null;
};
