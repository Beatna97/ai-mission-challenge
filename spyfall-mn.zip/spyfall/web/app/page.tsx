'use client';
import { useRouter } from 'next/navigation';
import Shell from '@/components/Shell';

type GameCardProps = { title: string; eyebrow: string; description: string; icon: string; tone: 'gold' | 'sky'; available?: boolean; onClick?: () => void };

function GameCard({ title, eyebrow, description, icon, tone, available, onClick }: GameCardProps) {
  const palette = tone === 'gold'
    ? 'border-gold/30 bg-gradient-to-br from-gold/[.14] to-panel/50 hover:border-gold/70'
    : 'border-sky/20 bg-gradient-to-br from-sky/[.10] to-panel/50 hover:border-sky/50';
  const iconColor = tone === 'gold' ? 'bg-gold text-ink' : 'bg-sky/15 text-sky';
  return (
    <button disabled={!available} onClick={onClick} className={`group relative w-full overflow-hidden rounded-[1.75rem] border p-5 text-left transition duration-300 ${palette} ${available ? 'hover:-translate-y-1 hover:shadow-2xl' : 'cursor-default opacity-75'}`}>
      <div className="absolute -right-8 -top-10 h-32 w-32 rounded-full bg-white/[.04] blur-2xl transition group-hover:scale-150" />
      <div className="relative flex items-start justify-between gap-4">
        <div className={`grid h-12 w-12 place-items-center rounded-2xl text-2xl shadow-lg ${iconColor}`}>{icon}</div>
        {available ? <span className="rounded-full border border-sky/25 bg-sky/10 px-2.5 py-1 text-[9px] font-bold uppercase tracking-[.16em] text-sky">Тоглох</span> : <span className="rounded-full border border-white/10 bg-white/[.05] px-2.5 py-1 text-[9px] font-bold uppercase tracking-[.14em] text-slate-400">Удахгүй</span>}
      </div>
      <p className="relative mt-6 text-[10px] font-bold uppercase tracking-[.22em] text-slate-400">{eyebrow}</p>
      <h2 className="relative mt-2 font-display text-2xl text-slate-100">{title}</h2>
      <p className="relative mt-2 max-w-xs text-sm leading-6 text-slate-300">{description}</p>
      {available && <span className="relative mt-5 inline-flex items-center gap-2 text-xs font-bold text-gold">Lobby үүсгэх <span className="transition-transform group-hover:translate-x-1">→</span></span>}
    </button>
  );
}

export default function Home() {
  const router = useRouter();
  return (
    <Shell>
      <section className="soft-rise mt-4">
        <div className="mb-5 flex items-center gap-2 text-xs font-bold uppercase tracking-[.24em] text-sky"><span className="h-px w-8 bg-sky/50" /> Тоглоомын төв</div>
        <h1 className="font-display text-5xl leading-[1.02] tracking-[-.06em] text-slate-100 sm:text-6xl">Багтайгаа<br /><span className="text-gold">тогло.</span></h1>
        <p className="mt-5 max-w-sm text-base leading-7 text-slate-300">Найзуудтайгаа ярилцаж, сэжиглэж, нууц дүрүүдийг ол.</p>
      </section>
      <section className="soft-rise delay-1 mt-9 space-y-3">
        <div className="flex items-end justify-between px-1"><div><p className="label">Сонгох тоглоом</p><h2 className="mt-2 font-display text-lg text-slate-100">Оройн тоглоомын цэс</h2></div><span className="text-xs text-slate-500">01 / 02</span></div>
        <GameCard title="Шпи" eyebrow="Social deduction · 4–8 хүн" description="Нэг нь шпи. Бусад нь байршлыг мэднэ. Яриагаар үнэнийг ол." icon="◉" tone="gold" available onClick={() => router.push('/spyfall')} />
        <GameCard title="Codenames" eyebrow="Team word game · 4+ хүн" description="Багийнхандаа оновчтой clue өгч, нууц үгсийг зөв таалга." icon="✣" tone="sky" />
      </section>
      <div className="soft-rise delay-2 mt-6 flex items-center justify-center gap-2 text-[10px] font-bold uppercase tracking-[.18em] text-slate-500"><span className="h-1.5 w-1.5 rounded-full bg-gold" /> Илүү олон тоглоом удахгүй нэмэгдэнэ</div>
    </Shell>
  );
}
