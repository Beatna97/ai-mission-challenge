'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Shell from '@/components/Shell';
import { getKey, getSocket, loadName, saveName } from '@/lib/socket';
import { t } from '@/lib/i18n';

type Ack = { ok: boolean; error?: string; code?: string };

export default function Home() {
  const router = useRouter();
  const [name, setName] = useState('');
  const [code, setCode] = useState('');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);

  // Coming back to the home page always frees the old seat.
  useEffect(() => { setName(loadName()); getSocket().emit('room:leave'); }, []);

  const go = (ev: 'room:create' | 'room:join') => {
    const n = name.trim();
    if (!n) return setErr(t.errors.name);
    if (ev === 'room:join' && code.length !== 6) return setErr(t.errors.not_found);
    saveName(n); setBusy(true); setErr('');
    getSocket().emit(ev, { name: n, code, key: getKey() }, (r: Ack) => {
      setBusy(false);
      if (r.ok) router.push(`/room/${r.code ?? code}`);
      else setErr(t.errors[r.error as keyof typeof t.errors] ?? t.errors.generic);
    });
  };

  return (
    <Shell>
      <h1 className="mt-10 font-display text-6xl leading-none text-gold">Шпи</h1>
      <p className="mt-3 max-w-xs text-slate-300">{t.tagline}</p>
      <div className="card mt-8 space-y-4">
        <div>
          <label className="label" htmlFor="n">{t.name}</label>
          <input id="n" className="input mt-1" maxLength={16} value={name} onChange={(e) => setName(e.target.value)} />
        </div>
        <button className="btn btn-gold w-full" disabled={busy} onClick={() => go('room:create')}>{t.createRoom}</button>
        <div className="border-t border-white/10 pt-4">
          <label className="label" htmlFor="c">{t.roomCode}</label>
          <div className="mt-1 flex gap-2">
            <input
              id="c" className="input min-w-0 flex-1 font-display tracking-[0.25em]" inputMode="numeric" maxLength={6}
              placeholder="000000" value={code}
              onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))}
              onKeyDown={(e) => e.key === 'Enter' && go('room:join')}
            />
            <button className="btn btn-ghost shrink-0" disabled={busy} onClick={() => go('room:join')}>{t.joinRoom}</button>
          </div>
        </div>
        {err && <p role="alert" className="text-sm text-ember">{err}</p>}
      </div>
    </Shell>
  );
}
