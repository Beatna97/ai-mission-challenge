'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Shell from '@/components/Shell';

export default function AuthPage() {
  const router = useRouter();
  const [mode, setMode] = useState<'login' | 'signup'>('signup');
  const [contact, setContact] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const submit = () => {
    if (!contact.trim() || password.length < 4) return setError('И-мэйл/утас болон 4-өөс дээш тэмдэгттэй нууц үг оруулна уу.');
    localStorage.setItem('sf_account', contact.trim());
    localStorage.setItem('sf_profile', JSON.stringify({ contact: contact.trim(), name: contact.includes('@') ? contact.split('@')[0] : 'Тоглогч', skin: 'gold' }));
    router.push('/profile');
  };
  return <Shell><section className="soft-rise mt-4"><p className="label">Тоглогчийн бүртгэл</p><h1 className="mt-3 font-display text-4xl text-gold">Тавтай морил.</h1><p className="mt-4 max-w-sm text-sm leading-6 text-slate-300">Профайлаа хадгалж, lobby бүрт өөрийн дүрс болон skin-ээр орно.</p></section><div className="card soft-rise delay-1 mt-7 space-y-5"><div className="grid grid-cols-2 rounded-2xl bg-black/20 p-1"><button onClick={() => setMode('signup')} className={`rounded-xl px-3 py-2 text-xs font-bold ${mode === 'signup' ? 'bg-gold text-ink' : 'text-slate-400'}`}>Бүртгэл үүсгэх</button><button onClick={() => setMode('login')} className={`rounded-xl px-3 py-2 text-xs font-bold ${mode === 'login' ? 'bg-gold text-ink' : 'text-slate-400'}`}>Нэвтрэх</button></div><div><label className="label" htmlFor="contact">И-мэйл эсвэл утас</label><input id="contact" className="input mt-1" placeholder="name@email.com / 99112233" value={contact} onChange={(e) => setContact(e.target.value)} /></div><div><label className="label" htmlFor="password">Нууц үг</label><input id="password" type="password" className="input mt-1" placeholder="••••••••" value={password} onChange={(e) => setPassword(e.target.value)} /></div>{error && <p className="text-sm text-ember">{error}</p>}<button onClick={submit} className="btn btn-gold w-full">{mode === 'signup' ? 'Бүртгэл үүсгэх' : 'Нэвтрэх'} <span className="ml-2">→</span></button><p className="text-center text-[10px] leading-5 text-slate-500">Preview горим: OTP баталгаажуулалтыг дараагийн backend хувилбарт холбоно.</p></div></Shell>;
}
